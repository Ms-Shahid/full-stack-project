package com.company.HotelBookingManagementSystem;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HotelBookingManagementSystemApplicationTests {

	@Test
	void contextLoads() {
	}

}
