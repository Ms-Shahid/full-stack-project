package com.hbm.hotelbookingsmanagementsystem;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class HotelbookingsmanagementsystemApplication {

	public static void main(String[] args) {
		SpringApplication.run(HotelbookingsmanagementsystemApplication.class, args);
	}

}
