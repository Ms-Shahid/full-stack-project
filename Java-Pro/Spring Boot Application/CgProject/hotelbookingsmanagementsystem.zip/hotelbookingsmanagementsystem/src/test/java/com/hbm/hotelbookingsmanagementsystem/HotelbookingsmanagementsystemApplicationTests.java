package com.hbm.hotelbookingsmanagementsystem;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HotelbookingsmanagementsystemApplicationTests {

	@Test
	void contextLoads() {
	}

}
